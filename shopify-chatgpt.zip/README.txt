# Shopify ChatGPT Backend (Vercel)

## Steps to Deploy
1. Go to https://vercel.com and create a new project.
2. Upload this folder as your project.
3. In Vercel dashboard → Settings → Environment Variables, add:
   OPENAI_API_KEY = your_openai_api_key_here
4. Deploy the project.
5. After deployment, you'll get a URL like:
   https://your-vercel-project.vercel.app/api/chat
6. Copy that URL into the 'apiURL' variable in `embed-code.html`.
7. Paste the contents of `embed-code.html` into Shopify's `theme.liquid` before </body>.

Enjoy your ChatGPT chatbot!
